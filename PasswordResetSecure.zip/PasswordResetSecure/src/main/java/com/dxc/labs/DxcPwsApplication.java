package com.dxc.labs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DxcPwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DxcPwsApplication.class, args);
	}
}
